<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2c1b52965df553acb68ce8c5f30f23cf',
      'native_key' => 'core',
      'filename' => 'modNamespace/e7294d0a8e3f27504fc0fa3467536762.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => 'fca4e35fda49bcd06fc8d9490428df7d',
      'native_key' => 1,
      'filename' => 'modWorkspace/09fe689c35f01272e8a531264b319a66.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '8db2a9cfc56f90c14c2d027979ade6aa',
      'native_key' => 1,
      'filename' => 'modTransportProvider/2038fbaa0e9489528f05ed67b33ce97c.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0bf675555b42953b9d5319dfb260166a',
      'native_key' => 'topnav',
      'filename' => 'modMenu/c84cbdab9998775ddc1ba2f991c75a21.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1db83d8f5e0129271bb2b07d75fa43d1',
      'native_key' => 'usernav',
      'filename' => 'modMenu/fbc3abaec830deb1a285c0cdd3d041ed.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'da3e704ae35f0aaef78e521988538055',
      'native_key' => 1,
      'filename' => 'modContentType/c7ec60009e6b427c5791e802551e01e7.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e6a98744bf8aac684bdd22802032e815',
      'native_key' => 2,
      'filename' => 'modContentType/c4587a94a86c88e74a7245981b1698c1.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '31c4aab79db805f8177542242e5ac464',
      'native_key' => 3,
      'filename' => 'modContentType/a9b69c57a7eb0dc2ddc2f7717f28c9ec.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '27dfd81c54ef90c07362a9df1c2c9497',
      'native_key' => 4,
      'filename' => 'modContentType/9027e3eb46f58b9b22c9424c6d11e88e.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '164568342ef6db58c4b6b0644b75dcf0',
      'native_key' => 5,
      'filename' => 'modContentType/1e3e52e61174f3185525382cb120be1f.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '2eaed1571e1085e1a1ea31868871eda2',
      'native_key' => 6,
      'filename' => 'modContentType/88748e9d569b210598f9039a6e4e016e.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '66b178408ba6999b6bab188760c0fb78',
      'native_key' => 7,
      'filename' => 'modContentType/860fc0a2a7fe2660ae4682e68d7ae8ed.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '692a572962c689fadf5064f6f14df976',
      'native_key' => 8,
      'filename' => 'modContentType/3ab0d80b9a4d1b67efbd8f787b1bd7d6.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '505041b809ec4798c9ec80306881ee28',
      'native_key' => NULL,
      'filename' => 'modClassMap/7e19082a577e84aa476661fbac407943.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'ab56b576860f017d21de9c9a95388971',
      'native_key' => NULL,
      'filename' => 'modClassMap/428c4eb8452ddfce069797ec7848f435.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'ca40edd5d3252938e956b16acc370bba',
      'native_key' => NULL,
      'filename' => 'modClassMap/6091186279906af204dfebf2cf6501cd.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '405bc1d355527e6593b3f57cb27c5836',
      'native_key' => NULL,
      'filename' => 'modClassMap/8c42ef3d3745c750ec4101e8f606f6ae.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7fb779136371489f2e47e60d0ccdf350',
      'native_key' => NULL,
      'filename' => 'modClassMap/da455b2b5775eb4d527602792d32192c.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '2e67236a75786d2eb68c0367b55f177e',
      'native_key' => NULL,
      'filename' => 'modClassMap/b8c69c6686ab86523a24f26d9d8a60e8.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '4c17dd515f4a9956f16df0fb7c4baa20',
      'native_key' => NULL,
      'filename' => 'modClassMap/77b044ab70bb5c2527d262f53420c955.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '019092242f691478311c8533603ede1d',
      'native_key' => NULL,
      'filename' => 'modClassMap/075702e0deadbcc1a92f8bae6a0ebfa6.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '8f56d821ce90c9150d9066243d8cb411',
      'native_key' => NULL,
      'filename' => 'modClassMap/bc3c40318818fc984d5a46de1bd9ab0a.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9016ae17287c7ba295ba71baa2b54dc7',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/628cf88d642215bd383fc0b86fb2b4d3.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0ccc548c3135a56a656fba5ede318bb',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/8f11778fcbacd3dff50075eb0a58dddf.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b684e1d0663ae2d7eeee4a25135060f',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/97b9df10da071b975c14c529c2a8d055.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '705b3c63cd6ed178e92d1bcb4432549c',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/ebb258f9b32b6dbeeed3c3e6f239f235.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0eda201c4d85853771b2317f827ca737',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/2b43647d9f5e6df651ec04609a88e5a3.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '92431bb3f59f6450c503765d86cc767b',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/694c3c7125b5de7af328d949f9695a7a.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c276f024accc5435259e9a3d91712080',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/3c49ecada1ee30eb1e6dc2437d222028.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '149072f274d176367ec01d24843a3ce5',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/6a9f5dcfb3a0851e7b8219e9266e30a0.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e2d629e3a0b779f39b6b1608c4e114f',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/8b4ff3569fbacc586353114fe34a80e6.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd95e2ad80736866f6de235f765509ecf',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/7cc45f016d41df916508999bcc44e90c.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e5fe918f349505a95e66446c9e56570',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/69cff21bf9306f342455a8849a0d5dfa.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6693ad29486689391929589ac02fc24a',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/658f92eb2c884e52232062279592a1d3.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b015ce64369e9efb1c80165d754bdb63',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/8f45bc59ece4b1e33c49d10cedd75590.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '15c8f055ae8331a907888fd267456c85',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/e8a14d106278f87b05317bb97dcce9e3.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '944d9868cbfea9980cc8f7e1c026bc50',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/b97245c9100cab4ea5dc1edaea967bdd.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a73d7fd78616f3fbb1629117634ce1aa',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/5f647b3d25b15b0956b6fab37a95083f.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec00f6ea3e77d580c600fdaa2269ec86',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/5442a823cd9382c16bab6d33603afe2d.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a151c1ecc9e9ba2eb623ce1e5be76041',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/f91ec8a52e3b9219ff8fbfbc26abd9a8.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3107cba9e408d74f5faa0c37ec9bc667',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/aec384d069107e3b0a75b7934748b67e.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd32918457910d44f65a5f6ada60ec94',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/702d85984bd853b83cfd3846c8ed7017.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce7701ebd5a0663a3e6827e9e3744bab',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/0dbf36d694f442480b24ac48a057d99d.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c39266ec49134142bda299b2a8b0e059',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/70aa1ce96b5ae7a1982a7ee1b71a10f3.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa300a430864335523aeb7890259e3a1',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/96f284258e9d75e2ef41d772292cd0ce.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '172ffd7c345eca9de0e09e14d9027055',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/728adc8f8fc412857a5bbb415ff26745.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7535b77c44f63711dd68618e470a1dae',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/d1ec310995ee517f445fb59f1de734f1.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4ed116a6f8f0013d817f586d4a1fa14',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/e905e4317372be25dd956e9230de0e8f.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e91baacbbcb273c545fe0e88fce2cd21',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/8b39bfea383c57b1b8855bbfeb31f06d.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '04e71f762d67cf502c0848db69f81c3c',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/726f83243c20b31c475580eaac80693b.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e83c4c1bd7674d015023e8e150aab1f',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/84f0d1f6eec10a95e102450f6ed679bf.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c592db2bbe8fdc944929678c9f818429',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/53b7ca11be3c9bbc264076cd6e2478a5.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb1efb9612417612f7999e134a57e068',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/126759824561d0f22000babfd312a585.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df056b76a607ded7ea7c5ccd04d99a8e',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/29351305a18788289bc5e5da0a3bba44.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6cb4e7f6414d5c641e526b816618ff89',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/08fb842ea3f8e583d61fc4332bd51a0a.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f276cf59bdfb2b3b8c66f60a276849c',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/67129074266af87e9e06cfba87c64b78.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '79f421d085ea910fc870c11bfe92b186',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/257cf8cbec5da1918a9ee7c2f54d183b.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '810ab155e08ffac48a4e871eee15c0fc',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/c5c7f56e481409720c250037e828c96a.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56dac17a7592a582129665e61053a4b9',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/77b20e8796c5855a10a44a9f234434fb.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '967f386946a01cc9f9d7434dac90bdeb',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/250cfb7aa08f6929eaed7fc798787a0e.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a218eee1e7cd1610d614b11e31306b09',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/06aa2bde83d52fbd468ab444bf6caefc.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6beac57aaeda2939115f4fad8fc7bff3',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/b675caa1204e10d5c9b18630c2638e74.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '561c6d927384599224b5917fab6a4b7f',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/5cd42af019f8c86725c9591209d46842.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7b7b319452721fd25f7642cc0300d688',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/5a933513741cf8190185f4d7cdc07b40.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd91d83a45f6b9675029d784292b69c92',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/28876b4a850a5c4e541437f06fba2b5c.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '89a27abddd0093ba22498bd4ce6c2f62',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/41f48f4eea8348199c3329b5ff8d40da.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f4273a15b04eb64cfaaa67ce7354fa58',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/bbfab49dd95bfd86ed1d2b7910eb9d27.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce70178a4384a78c746109bbdfc8d209',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/4c3774c2676906e6277590db505e7fe2.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd293cf1888b70abcbc3601df21cdc829',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/104846031ec75339d2af045adf488314.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2671b0c8741a98c305b7501986757bd5',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/dd9030356ef719a56a4465024a807275.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5914e4bb49c9e6842e1fdfcccd678e11',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/9602d8365f627fc90e4f18aaa3d08e94.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b99aec1e4b6de7ba3d83b8688f0befbb',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/3d72066a7eba867bd4ebd510e29374b5.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '476be97bf7944a614a642554bae00283',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/021dd79734dffab6c67720bb31da2cd6.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce5345ea705b0a7722e7cb7a9a97eabf',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/b52a90b2aa9b788e88b40d0cd7193119.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f63c71d3f2dfd2548da350be3797104b',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/f44bf5861fb7a2fc33163be1b35932e1.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b89082416f1dfc887bd4f00c195c5653',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/30e5c18e28c187c56c95f04b65bc6b38.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a6088d0adee36c3ca1c0f044f1e1e66',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/0521978a693d5db429b95366e416b5d3.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e3080251483994b103f744ec0d0b95f',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/2b199dee076b410feb5a730df8496a18.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1cd1ff81a58d13c0ad7b86def954383c',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/98b200563bd803064a68cc99107a58e8.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '958f165bdc5e0cd4f2a1109908fe41b4',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/6290d31529c046acd60a5903a64c78f7.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '27610890966741690665850f5553b549',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/e33f99525af39a0cecc4e10f11ee401e.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3bbd73415595b49910f4bee8e503f7eb',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/004b6394071b8f5f50b0270fd40b5b42.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '179e3df00db23f84d5fe42ad5b905a8c',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/dc0601818641da708d370194f7b7d0a9.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e70c7005a3b75858e0ba3a9acb11c4e7',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/22ea1b2af1ab9e5e6d2bd13d7dba0c06.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cef95766f3cdfc072c96337088a9d9d5',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/770979b8e2b2f739e9413283d4a18393.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4f039fe87c37d9708c19250c1201624',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/db9ec59694f52b4e462a5729a7f38827.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '238892f6a1dfc87cd9ebe61cf07a9469',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/62d7920181f05fd5f331fad714264f55.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb9805ac5c5a4cd564e52be8b677ac10',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/781f3c1cc70a4908bbffbe4463735865.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec2ef0523f41d284a6b7a5ed01a583dc',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/5e6782e401ed72dfcba10bfae31e101a.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9db9ae9d7ec68c7e1173d8a1fb4beb24',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/30fa49f9e9e188faed13ea790cacf88d.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b8f299aaf7773b75a6a18cdee946e17e',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/e4bf21ce12683da51bebcf78adee7c86.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad04beff690c23e1f9535ac5fdab87be',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/1064bffdc18521a0614fef1ca48836a5.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb4e3a8b41208ad71a39de293e0e78ac',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/0a454e8a7c0bd658022ec0e9ae57d8f2.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5681bbcf4ae0323115565abfa46dc17e',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/265cdafda52067f4f4a3ed464d4cc272.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '849d69f14d22e474e20457f2b333e77e',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/93f468f3907a1d84d8f8bbb17bdefbdb.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7fee7030383e34ee1bb3fe6061876fbc',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/805d5c1279d15784779a05fd78247e16.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '177431a30d1ba585309021d3e11b6900',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/d9f1ac5b0b06b92f4b8ce22a30889078.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9547f353b81835bceffb6ae60ddfb2c0',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/0f2d28e35bfa2fffec2572cb49709e67.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55be436f1f679bc4f80cf22ad5af57f4',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/ef054ed61da6edeae7d3e177d58583cb.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41c584c6e13afb99b1b6436e0643b56f',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/79242a3eabeb1b71eb8089ed84127fb6.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f13ca0eff6f7ed550dc38c7631069ebe',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/3d62ed2a85cfaaa2212a721ca72aaac0.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '070214e0aa76a7c28f74d761888dea54',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/f7a4c886d63cbf671d5860e9b72095fb.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e555c9ed95ea1fd50e06607a339bd9ec',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/602f172d2894ffab8932d6ece45dacc2.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd8413ada09374e9c37ec583ce5ede30',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/a4e78270aaefe217ca37d23d81d05581.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2795fcaecde25a2b15df1cd16801db7',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/0af7133055fcb08f9af9d2a4e5218d3f.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3fbde442d964b407194d1d3ed01e658e',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/5ca759cc84a98173f61fcaf4885c69bc.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dee9bd4339cb05a18ced4bd82b9dea5d',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/d28372274c9a1f1e5cbe5bf559565e23.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '48e978db8206edbeacd708ae893af0be',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/617906473303a349b22bec00fae9e9ba.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c24708179060b3b5fda090b7dcf1a737',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/f1c61e34fbe76d041dc9f3bc67544a3c.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7de6d4629fc14845188926857d5c0d9f',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/830e402447fc9bb435d16acc3ae9b818.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76660bfb5ffa7ccfdc8b5a5d55e869fd',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/6aa470b38bb00d55a1c6fbb73322dbfb.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bda36bc2a2f42bde3a13571fa6715ae3',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/3c035a0de2e03ef37e9e8f4a086bfee9.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ad384e4466b2371779dfbe8a7ca2eef',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/0f90fca01bf516f8cc8ddcc76f1df9a4.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6be2f56963ba671339fbf8fd4e2329ad',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/b18a900cc9fbed344f525a83a60de642.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb49f3e440eabb155e2436f5f4df0075',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/6e2801d847ff5ebf06126ce6411022c3.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7cf7ae867516c062cd5babd641e3347',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/09784e15b83bf6de3b6d793b85a9c13d.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e31ba4e02412049bd5c182448c988679',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/99275c95e55d34d0f817bfe4dad3cfc3.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a30899595d8706afd8fe2ae10e3e4d1c',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/ee224256b79539fdf8240dbe6d1b66af.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7031add47cde4c71fdbb2f398ef9affc',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/34fdf38bbdbf091e5d607f254507adc4.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '34f6a6c252c6d77f31475668a05e389f',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/e90b8f09fa7aeb73fd4a05e0a152e1a2.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '702ad15e3328a36746f89d0214ed2f4b',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/70a376be69d496ff522176b6c9b6ca51.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c58e660603ce3b6d943c74dc67c7e2b0',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/27d436a4fa610edf02ac062acff85873.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7dd2026f348655a47cc0c3b52f97e459',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/f9ec43c1bc403bbbcd5ff2a08ffb8f5a.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '256116844c7c7a91994bda6ead59c7f7',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/1e138968637177998d82212a920afa73.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '52f0a4395b3e3637c5740f29ae434c0f',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/23f02b79052f23c80fd1a3e5623d2feb.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7d2ac4ff94881caf18472869eced423',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/e78acf5c09a9c1213b534452ec2933c1.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '03debf9fab0ce94f43397424901a8ec5',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/a3d9c20241a7926e7df3a21861143591.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8dac55621d61de67f5676e6c9f7f2833',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/1573951222042d145bf11e817128a063.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '376dded03376500817436906e15b0f3f',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/94d3a0170ab50357adf1f4a6eec1560a.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '574480dd8e82f45f47a409c381367814',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/dd338004cedde4e90c525362c487e674.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e97b8a810fe754212db31184fdb0c10',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/92385b3db582fca58dfb8fc0d1fc774f.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be0bf616fc4bec67d049625d7f6a015d',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/01840bf1b2a40085fadb39a74d6c665f.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d03e90ccb152f9e9c3b958befbf2dc7',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/ffe51227daa1d2c460a8e6f0a2cce566.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de932096b7afaa0f78282773d54826c7',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/e1b92a19fb9bc1a34ca53864a98deb92.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '458612fce77cfdb53f0eeee3097896f6',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/ed33256757db31198a0bf03bc07bcb1d.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd1fe348c542955babee66d3226fe115',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/b048167d20b25c533ea20315af83c227.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f1c183de9eb7706bf52a2704012c1e16',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'modEvent/9ed9c63a14ff7eab412401852a4a17ae.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4bc089f6c856de62a28e008072250227',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/2a6997818ea4003e2f1a324c3c2e1d99.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c27481101039cec806c57399f22cc01a',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/2f8544bf51cb3876481ef3a9d6ceb8f5.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '98fb6f6c0f8e02710880f3cfc4e0c29d',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/ec4abcc61771ff0eda9732047ab42de8.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6abc23e5de7758e8fa3115b75bd2149f',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/d85854e6eee85599304db3c6edf6a887.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e75085c6e302d8b0f000aff7453ffffa',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/1fef4ec84bf94d20d4e8ce207ff1193d.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd31cd54fc68315885106728f13127c8',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/16cbc9fc0457588b8c9e5c38e39b89bb.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f754a37c6b4f55aafd8af5488b61439',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/ac70682f71faf5c9d50fbed14ad84ab5.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2031b8daf897799f55fa94de20b52657',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/f6e599383e5cae8cb652b193106204bd.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a6eab03e57298456a66018ac3a2f732',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/686a75513951f84293520f5505d57c93.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '723c8ab0d13978fa6443b532b6392dec',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/7c1b4a257674a6b083108d7d0cc87729.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf2f202c9a6a2552d8c6f028e20b430f',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/ed1095c774e163a21aec95c99de8481a.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '973b5ab35720bbbd504917996f16d1fe',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/12170aa474d9854c2279cabb1ec484ef.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '061aa7839b637e202ffebc1c01bfb677',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/44662b21e5aa4fee79cd976567149dd1.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '830a5f85254d8f57fc31593acbe793dd',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/0ec7a23800b6e196c8159a5750a17473.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd678ea0df8e3515c945fc81339f3b033',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/159808aeb7c42a0c5aa73938bc8db747.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66905c029a819546bcee69b8a5549495',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/5daf4917677efa0bbcbe9e5a0de84857.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5491ac223723a4af82c6497fbfd89f94',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/3398337d89d999b202ba3dbf7cc7e671.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c72ca188807d38f74e77cbbe868f4ba',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/7aafaaa4975d8e27437a3e19b6a068d2.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3f981b66a543cd4daabedde0c0cebcf',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/b20b2a3f4ba4b332127ed58d557149bd.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2023c8d1e8dbf466f9109f1fad47b72c',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/42bab690ad2620a9c206049e103b700c.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b813cd0f6a1da4702b51665d59534e73',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/ce4c7cd5f728810e1e20213208f69f66.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd84e0daffc310f6a72673a5aeac256ed',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/2a049de4f619296e89bbae2d435a886d.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b83ae95017b8d57f84dece0c1b368ca',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/db00658681975cadab8afbe11b29b75f.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e89020f0716e57b3e735a2a311f5e55c',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/7ddfb2497f99e4f6da90c98967b21142.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '64b96dcbbd6e2792629b520219f04905',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/525b33d4e7e7fd69b7b3e6e5f708d5cd.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '79dafd493447fc4bc446f95ec5ef17d7',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/4a10d9a72b45c50000a2107d33cada07.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '956f71085bc18f9c190e0db6f66b92f1',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/7adaa4bf5a00fba25422dda07acef58e.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '780c85eb88af15fe676853ffaa8efcb9',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/72285e97fb12bda722ba9063c43b2341.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'efe1f782f2b78afc1c18faa5e857ed69',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/b9c5469bf31e1e603c2123832861c688.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fda170185fcf7a230b9ed9cd9d09ef14',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/a2892110e6678ea830b7f59b8afca2fc.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be67f7af7c61d17c6c45522b4e09310f',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/114cc4cc63a147988b22bf18b591ffae.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4e039efd2e461b3ae5562ecfa49e10d',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/c8ab987f2ac775ffea11988d562f6469.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e00cad7aa42c4faeee9090c3e5a0af15',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/4f0bed18bd922029a64ed238e0f0f780.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '27aaf58957f3bafca8525f5c722754eb',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/0d6d2799c588e1ba651eb1ba42dcf27b.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ede446346317a7d937e3fbad89e13e1a',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/c6a1734f84563849492e73eb76bc9ea9.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1e412c2ccf9bb5f7e366eec6630fb69',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/096c2732d89d3ce6fcf07e5c4d67ca74.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7dc762ad93fdec912a74648da5a434fa',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/33c59c40405348fbffbee771c0ebdb01.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9cfbec027ae5c3afa7cf475c79677249',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/177cdf36028982f73c857c6f62e3b26f.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b8c73092a569b5afcbf0f1cb2f2c0751',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/d4f6c5aed4d3eb747261edcafeb6baa5.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e530ac5a468cb0ef418bcf164f5c151',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/074cc06976f0cc03e6de80bf3c45ee1c.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f3c0d2b010f4f7f6e1271a407169500e',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/85eac2868cc2b9f03f68e9c13a1821c2.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '855ade58ba4e025bf7a26c9ba9193b57',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/5ff259da022c8804d4a066f3af8407e0.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a38b62b1ca0678d50644f2fe7710f8d',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/22f064015641f5973a0a4a8ebc920624.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40b387083d94b50b5aaeb67b26f681b9',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/3c0819f3889670b0921a63e146849dc2.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9dd0e7d466c98d7d874515705503850a',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/8400d8e74be15b578559395d57da2b5d.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f5bc529972a3b00c6a4a932d86aebba',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/311582f91722b8d069e0c0b8f521e2db.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbaeb4914ffbc29495db3cfafdb2c094',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/079a2dd32faadd9e88e1ed0d6b9d2e27.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '45b2a291051dc562b3d7e8a40556a8aa',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/bb2a84c69576eebea6f285a7ea545e0d.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '020fef05de6e4a9f7456a669d8121557',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/1fb55dfd1b76c75e5e0c985620734ce5.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '702a9fbbc85a9d7553f934df4d40ae86',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/6a781f45b5f8d3daea5b3732d7b18eec.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b319a5dd6708d122bedcf212070dad0',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/1734c845e815b3fd83c0f089dadf2059.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa6c345e029d8fb68487f452eaefb09a',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/284431530cb0c3561802b733a8ae9de6.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96a0be39d5dbfa03e027a81a21ada392',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/d2c7eaa51314d8de6221fadc6997a52f.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c33aee7c5f7fec5d5cb01c3fd6185492',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/51dfba77e574c675eaa189484dd2fc43.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb56cff75e050abbdd3dd70f429bd296',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/a0f84d4266ecdae1f6236acb9252286f.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c8f9f736e9a0fa12e7f9ed096e0f8b8',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/36616342ae87b07889bab22438a946bc.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29052212a4350c30f49b4f875bae1925',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/433c19126e0aed7d9a3393b94a15a5cb.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2c1610feda525e4b723cfce257ed2db',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/f70a4d9913c3430592fbd5402d3748e4.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'afef5f972dc395cfe07f4c5185b1373e',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/c4d775346ad5992a656ea9efa024a40a.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '682f61847b8910a1757404c68289d805',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/72ad3d658e9ab6d0c2d109a8f4d0387f.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '249368f687ab1462de53b8f0ccd55594',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/f4976a6b9a896e0bfea706a69d184265.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '92507ae8c86573f23c441c220396b4bd',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/5ef89676dd400e443585a1c20d9515a2.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f679c676b0481bfa184280ab58699773',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/454e040b9fce35009723951c31bcb51e.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1947ce2bb7c3f11c0f71ace5a15b2ed6',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/be4eb8db8984d6c124984c4fd3a07dfd.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e6a649f57b874d161a91cdbd5a89f17',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/0c55b96f265708ad8ca9129cb725d856.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa0fdef999310337d22c32468a2fe2b0',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/42122a0c51d4e06152f1f0f267890057.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '71ac1cacd0bebbd7d45168d8be65d71d',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/7edf3c7ff49b47b1fa80be0ca400ee8f.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c3a55e9554d740468e47fcab469a2671',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/3f20fb9d01ff2e2cf8e28ea3305b7502.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9556cebdb87cafbc41d8ae80a1f9ef73',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/c76085f26ed8cb94e0fd05ce214936be.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '04844474f0ae491c1091976cf9d64b21',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/6675024a05a0a5653dac4e4ee830ce44.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5bdf384fa84b8767eb467b7784a0cf81',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/c53e4703f75d91cc1ced88242919313e.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e91e5c9ad357adc4244e30158a916a3',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/9c5ba75d24eab2a1b86d7417eebeed07.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2398ebc3a44c6f5c167db9eac11c068a',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/fac6cf90dbd9c6ea22a429301eb7be32.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af9359d9a1b4475973e7a4228e2249eb',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/9e75bd06c0191a40bfb5c972096b9716.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e08fff5af6f403e44089f962d10f10d',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/ba3a4ba433f7b0ba6b6203f0f53899d9.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16cbfb99fc93a0e027163876ecd14920',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/ec25bbdd7f40d29b9fd068b9b37bae81.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97546c352f8a240e9bd99eea0edf64ef',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/5da6b77ee87d7983644ab08ff6563329.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4e49a02c8b294e255c3e5f7c0c1edd1',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/b48fa29998478aab3bc047dd8f926bbb.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '521b647d6e4f5cbb674014c4f04af38b',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/ec0d5d6295c039c4500cc07e5e2d028a.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '585c9e9aba3c230e626f479cb5941dc2',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/136a9386e9ea101fea654ceb17bfcdd3.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c97e8f1b6573e13ac7d42e376fa6c1a',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/60fad3333c6a47300b8245dd802cbb47.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af2f69d4486ce31390d1ca1c525a2e48',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/19be5b8adb4e88d7c82cb480411fe279.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f31c5149d8ff5b0aa200caac4e7a09c8',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/7cf86e1ced14efde08d59b5d70cd6f08.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '675cb67d7cda330c6ffc74209647ce2d',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/cc09f5d6606a089a378d9daa4cd89cea.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d8df49e0f530c48bc4e21a680fb8303',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/1bec93b724bb7960977cd036cc4e20a0.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c54d141c4740c60b751bf624c4008e04',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/a670993ce4e955e62208e0591ddffdcf.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52aeeee736efae419001c13bf74de2e3',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/988ec0b267c814c86f078aeca50def4c.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5356b94cdb5ed2e4d3d19da8b0554ba',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'modSystemSetting/d665d2b9c69505f3b7cf336dab39834f.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a5af020c4b22d0e8c9b7baedd691dc0',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/62ecfaec5280658b46b8034c0ddd728f.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ccf9c7dce9e2f0dbbe6311ab8abbf73',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/9e66021fb36128d328cb4ec71cbd7adf.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d82f12714a27e246a991773b72dd8d7',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/aa9af28f2b3bf91287784b91b2307c2c.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd438f3fb19cbe2c61ae63655515f1217',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/b2377d7eefeb6b7446e847165694ac62.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73f25ed198de7e11467dae8f9190a5cd',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/b9612487006ff711e7aedc8cde9fca51.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58856cfce65f40e083d8fdb5eb72482e',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/86ed20429aac4abaa9037aca6f6e3be6.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bd414a1a3cab7d72cd046a541171d3d',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/036f6b3c48e2a6b604c27b3aa648c9a2.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e93f5bb209c40a275840c598d8eeeb0f',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/0e72db1498de456f7ef78372d0ccc69f.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b750ac1f7d8422e5eee81f80d8de2490',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/38c05dd3ebb61dc852886a993faac26d.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a028a6576a3a5a97a6b0359b33fcfc1',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/f21d42d5c1104e708dcf1febb6ef3bbd.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b124c9b35dfa29a74a5ed90a9ac52877',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/06b3eb5143cd327ee9eb8239cf036a89.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58189dfabcd075608f7b3b3dac7ff42a',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/28b5c5760c2e336fa022304fb60fda5b.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c58aa9692decbcaa033d77aa10184ae4',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/bf9a21a04b632b6062c5393bdfe866ec.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '041bfa0ec8c83891583b6084363bcf9e',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/11062eec82f1d0edff94d1703cabcd48.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c581d72210e8bc2cadb4bd84121baeb8',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/c7385462ac679f6a793cbdcdb5cbdbd7.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b64107fd5d15b62f022be576c3cc7b98',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/f978f5ed81101fd17c906cb77e14b717.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25088799e4d91b92d98d1df464c248dc',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/c38b0e9c2c290392d6be2fd97bdb5917.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04dd04d4848475416b7491f2dff72e4c',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/b22c2e967534b1e63f3d4e9f1906296e.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f9c6d9b84f8453c0f4573d0d5350674',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/8439585b1e68d4311259b4a843e93123.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4c318610c9f1acd6c7b58d8ebd34487',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'modSystemSetting/1af7391c7de31dc9348a40dc1cc83a47.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bfbd8364663e9482df22d28d654aab6d',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/667b72c589b105e418abcf94c1da02c6.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5d38f05ede29ed9047fba10ae5f12a1',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/71123554f52a6552c39b7b0fd9bb2df0.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f51b4a6c303d2e1c68b9d3217ed025cd',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/495d5c35aa9f2befcd4f189d8887bc06.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca7389f51f6866e9bcede9ae627fb706',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/458366a2b85a6e915f92226c4ba0e94f.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c89954977821a70a494d0e792e472184',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/b672b34c023d91401bccc3b0c230c5e1.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f8fa088cfc5d1c09acb6c93b19f66ff',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/3a2e6632dd73c80513e206aebb0872dc.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47556970cb17814a1dcc8c49306a80b0',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/8098e659f3b517f8e9baf67e9a646a77.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84d4b66e28c91d291163f8b2e7a3f44c',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/1ebdb73c676f4cbc018e244decc0288b.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0340e5538debc0cc26024d39f2dfc09',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/4c371aa479bcddb99b77b67ac6fffb8c.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eac6d9f1e3bf1616fb1a2286ad458889',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/44f801db0b3132f2dd415480e790e3d3.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc6b5e9ba3cf4a12941bd05ca686b6a5',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/2471de9b1774ae832f5fa1975d1f8e7b.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57b6b559001e505c1bbaa01b54d309c1',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/010f9e84d2d997bf73c79e4fbcd0844f.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b6f26aa74b4c95848c269f32f8bcd6d',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/a61f679a899990e2327b86de4f9ae84d.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40288fcce1b4c0fa46c675480413793f',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/63be2f80b2ce049703b9009c9c1c1751.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd135e8b525131dddac6fcfe14991471a',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/abee081e9fae1bc72f70591c6476b088.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13c6cdb6e619c4ae778e407291ad3e6c',
      'native_key' => 'default_media_source_type',
      'filename' => 'modSystemSetting/1843992d7103ac8a1ef2adfacd85ce9d.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd833245f94918badbb44324fa816d822',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/6bb48a3f0c8178779ee37f746833f55a.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c232314bd6feb3710d06682610a6b2e3',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/1628ff2326862913df91c209fe5078ce.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a773d26b9b383924a30cc7bd488db9d',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/a78b3ef1c0749df610760c6f14ba2f4f.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0455c280a3bf7bf2fc300e25027bbd1',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/fb5206b0bae92b80312bdd7b3b151325.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e26d342cc148b101756142836883033',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/e77615869d2487e717754743b45a2b7d.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef2a21818f118ba371ed360abb705f5e',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/b6d7887ab8f9b0e36b2a051aa19a871c.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86c0e709d5eed4ed36a333dc8f5eaab1',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/10d9dbc0b6df3a493e4b915fa1495daa.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a001c2746ed28efeb253841d81ee0b0',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/24ef3989ae9df6ac8ccbbb31d2dac22c.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a84eae3000d5432003d48c561ad1c3ba',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/0d8b77c720b82c1e50d0cb85178c290d.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2206a63021139451929447e63648cb4c',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/00dc3e96fce08f5a025151a648d5cf54.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'effaa85011fd31bd74aeca6446cf337e',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/e9153619124b96f300794e498c678e81.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '573adfa72f6ff6eee4d2fed25ba440ec',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/1ab5bc09309d4ec8b36ac0f80c8e57cd.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7dbc41c648aa7749c9c9c528f0bb2214',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/25fc185e30c4e7adfb0f48f09503ded4.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcc2ed12647c6147037afba4fa3d3063',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/e24a7af4bc66b1008162643d7595c59a.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa14705e291c425f33a9ef7dc224b5f3',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/24afa3f2a8ced9bc269d3e7639d5304c.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69c9347d14bb19c08eca45542a05cda6',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/375711fd6a616398ecb5d0d72a15a270.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90e1c000aa1a665ae003f35cb5189214',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/7e99a5c2cac620e5bf4fa14399fb7fe9.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bc1ba5f2dfcf3d1be0a09731eef3f91',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/5f5f5eb984bd6ce1131581a6f96093eb.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d48d8a9039f208f6bff72e1e60dfeed',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/642eb76a8a27ca6146c5eddd9c73694d.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ccba9f3f7d0c7e5e6fd0c619c6b3cc1',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/d55740331573876fb65dda58c72741a7.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe3483d43f719ba76d28449c69ef1be4',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/0d1bac9f8890ceeebcacc00306f64ad8.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80e2a2fec66faf02f693617c994fc9a9',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/496519020e11557754e7d3d8495c2a55.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33922d6299d5ef9f7f63d50ef92035d5',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/15ecbfa3a67b7d7a3db17751e3ac098a.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c280cc4b47ead57426eecea6dd30da2',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/76203aa6bf518aa54c289a10f37f3333.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6250e915ade1504cb2680bf674874a9f',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/c0a8dce0841bb5e09a4070836f5a6318.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3d1762585b60209c9e2872cacf82356',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/4805001c3648f23be3a5dc23105c5978.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a045633b2ad2c66d7e8cd5174e3a2fbc',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/1a792c4fb8ffc185d1025a8fabe093df.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1652db62f3ed4d38e62534228b5c84f4',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/485a09024bf0e0dd32fd6ff857fc3348.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '103313051abb9382b563bf52445a3290',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/3c06041952f187308aca5bdd91ca89bc.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7bba87ef754ffe0e6c05a0139c2a35c',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/c9ebb2ee92030537cb6e1f5dac93c2cb.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05f28ae2f816f0b0736af331a7bb7e54',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/5e803a625b5dcc381bbc9c20d79df1de.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8815492d3dae1e4cb751815e8c68668e',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/4585a92c9412be6692821508475db5b4.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c03f1274206ce205e4a9b473629c1e72',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/9612c4a892c9f2d6323847e9071a1b38.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00a04dfc149b42ceea484d1422ad5b36',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/0f5157081787d7a5c89befb9e2435074.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bdf8761d6a88733c9adcbbab9f584ee',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/cc7b2f2587635c9c904a49564432f6ae.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bcebd0dfb14c0b641a90fb5497a96a22',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/1b9c92fc53e5423911311519d6cd482c.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27cd72a3e3fbd71d30b9d338b5d913ed',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/d60673fe5b6e76e0cd9fe2dac9d9f8a9.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e4399a3e46b02f0280324f327eb3835',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/e450ce3006bb6cfe65edc80bd219c110.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcfdeb4378aa263c1e1810901f0725a8',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/0ec68fa985950a722ad09d8ae6de0672.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27d6b17a7b95805880a283427762937f',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/faa242bc34dfa81ba3c0b931e8de0d05.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b978bf46e40fe486a0d18d5e3c59ac3',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/49a7c7bd13bffb7f8fc58689607b0964.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5200bf4fc12fa7ff576d826ddffad35c',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/b07068e51a6e4c5b93480788b87f08a8.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e053f66df2cc99a11e23a0e41b9c0edc',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/b958befc97592e35e68e9f6c12ea830d.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27338be4cff4a9d7abb1471566585f87',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/fb19ec90f8449195d5dedfad69d9b07c.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f71d676c558c93d8f8dd4c9b75cea583',
      'native_key' => 'log_deprecated',
      'filename' => 'modSystemSetting/f594325dd9f7b28a435afb6060f213b2.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0574a2f0e64b69d73e2772643c6fbc24',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/a7203d71210e505650f7285f84298207.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dfb803abc32bac2e8ab8323fd4941cd7',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/d6ac9de1dbd0eb24bb44db14c1471d93.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54c4ff16dbf362fe6c66131f1c154e6d',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/fd9e5be7dff8704b7795d76493b3cef1.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30780ccd51ccd97578be2c7d1a027c64',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/3f31d592ac81e8b44bd0b34c808ec067.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02b2d5e092c0fe049d17f91013302ea1',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/f3a1686de0258f656da19fbce7deefaf.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a603f7236ea37652c34bfcf60a98d27',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/822c1058e9a57fcac3cb5ccddb23391d.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f78a905b91187d93d3ed68a02433fe5',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/93d6a3f6cf412b28155a1f0b980ba2f4.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c11b5bfcf6e3a026b515b3d9bcd9e11',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/b9c5b35741efe77e4a75cc078deb75e2.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f0b2decce9c5b3e980d2197861e15c1',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/de86d3c0a406356b6e57cac50069713d.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62983e6087124ce5ff51bd18d3c4bbbd',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/e6533734234a03bcecedccbb3e7ad488.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eced557caa3b1c02c39d26e0cad41505',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/fa6ddd3a9a844a57a0f79b8fb57f7688.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7908c65e3e665428cc2044305c36684',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/62d0e424529bbe829e8a78878700a768.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d1662362e81a57cb2115302327e26c6',
      'native_key' => 'mail_smtp_autotls',
      'filename' => 'modSystemSetting/d7f7043de0b33c2c49b8a48d5f1032cc.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20d06e7c299191801010761e9972299b',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/3c6a47cb7c404fcf9e1854262d10b056.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5acd60cb4312e8de0e0dfdba3b85575',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/60159a6c0cc2aab9c13122470941b5ed.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e8a3a3d2ce003ef8b0738ce1a144814',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/c7e03f0024c47179954ca1d489433d30.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e403ea89c565c38daeefa449318e6ff',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/872bb587eb59d847c3cc8e6099a11d48.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c8aba7b710f6c2f5e3bf529385a1433',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/1d84bdf2c87a3695abb51d866dce0c9a.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69e37ea1817f59ebf21533963411bd85',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/f1a5b634d72255975751cf08b88fa235.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf9385837eb78f7e45f9901f0918784d',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/cc36d2423832cf1f6f35a335b387501f.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f86be3c970c6369bbdd51691bf201f6',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/a317e5b22ea7a780b90569227df7854a.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e24321b3f4e3420189ecf1f38138735',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/a095f5f69620b38b98d46bfa41b649f1.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f04c1788a824c53b382c3e40e1d77ce',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/f87e5fbf349da3f7a380434fc9df764f.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae93b81790f2b0ece35aad5d7bbf64cf',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/e831d74a23e5a70f0620de810058cd4f.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ae43cb4147337bcb407542221cfd614',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/3cbfc87c22f72db0adf567e81708771a.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f46720f47603545ea55a708f5b07102e',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/df9de1b3ed51bf17230896fe631ca283.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ce560e4719f3f8b38c9cccac02c64fe',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/beb0c6065a3572b3a1107c5faa829c8f.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce24f1fcdfb98714bf9493dbf2929d6a',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/92b99027fded4ceb9c3392ac6be4fac1.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '351cc700aa6273d3d5c611b71e47dc27',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/aa3384ee5c6d8f55b9b9578e1571f84c.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd22a332f492461946ed01655f856c12f',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/a276fd5992e611329dced1a1c81a505e.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23609e539a4b2dda156ed854c7e65145',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/8f8cb64eecb2e6b63febf51cdd205e84.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b55ae27043512fa04ed27bba51c775d',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/39919aec7d7c73b964ec58ee4cc49e20.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b45eafbd7503892c4f92ade7c75f3ac8',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/b669e7bb9507790529ef482573e10682.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af6a9f1887ba9bead2db68ab9e988822',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/803b0682bc46cea0bcee558fb98fbd67.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5dbc913537caea69abe067de0c3b741f',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/513ff695f11eec28bb52db9f48ec1d6c.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6990245aeccfc80de84f15c8bba67592',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/041bb4fd31c39da840a60d7c9e1a6944.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'edd3e58c132a93c27819b7f57f006c98',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/5bf32190212fdc68e55d6c450c380a8a.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f59185d79811aa3c6939b7b42469ec3',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/cce9332d1929e0c1ae0facb824ceb7d4.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03838b4e1f75282942819b43807ef916',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/8322138492fc8c65e5024aa02a18f500.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '855e790f8242ed164696f95153e1fe1d',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/c27ae251026a3a218eb3e74583743a09.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab1b90dc23702234027a0575830ec633',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/1bd7353553c1c949e5d64a060d289662.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88549adcfb03a3a63a7d3ab57f0f672b',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/55d1a4761b0f259d9c333d694f516c77.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '076b38637f1cd404cb0678128744584b',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/faa51f01073535cd02df0d42aab267cb.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'caf067cdc5060b3ae0f9bb54ed11c7a2',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/4354372a33e86b396233671ac740e2be.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d6967de3b75065a019ebef85469c2e7',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/c6a564eeedd113fb640b0ca522c170d5.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '196b04b5a56ee8a84708e50bd66f914f',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/19ae774f7eefb67b77fd47278425e7c0.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b4224416f98243f42f67f05e6d4c27d',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/687d22538960e102cb6fc0b2abc77053.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3dc5d68a290d43e89a721d53c1694885',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/0fa20d7eb7dad364bc5c8d78ce6d4348.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b9f20da4668ebc44bec57512e87b382',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/2f905182a2efd78dfce1ee37448e0f96.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2274aa39bc65fe1b1e05b5938e3e0471',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/c9e9309815277561b51d566699f75acd.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a4ebffb101d4dfa0c871e959ee88576',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/c61ea5dcfdd47a12c96850099de7d822.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '400fc8b04ad03e3acbfc22da32473fd4',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/d593a289251f26e4cecce2941fc2947a.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28368d75b51ceff038ced2ee5b780317',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/9f9390b86f8aa86659a4221e8ef51e38.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86774126937eec7d124938d735b11152',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/b0e29571ca923f81787c9d01441358d3.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0d9b171d7435d79426c0d84719446de',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/5c9b2bf90c08dc9e892698a4efcea79f.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c237d076d3721344f35e4093b1bac8e',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/399d5fb3917fe623e7f758901337397d.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d52ed08f892c2bdf30b207649097963',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/aafed5bf2461e3cebec80cf845258fe4.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39bcc6493ff81acbb0601f48cbf59bb9',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/60a6d694374f281eb9bbd5f5934f432b.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc37f25b3fc69daa151f13d79a8d97f5',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/be5b46bd75a0ee4654e3a2df2c1938e8.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee849a50b66756baeab41805550742c0',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/f0caa54610363ffa50b0710753735af7.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '289acb19e32724f5228c87538d0dfb5d',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/5593fdb7f51573140347f8fb8df70d1b.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd21e641b10fbd9e21793a535f4d1355c',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/e07b0c2410d6e4c04830811fa50bf0cf.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa1b6ca372f289206e047c1941e24c05',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/f9a148d9c5ee47ddf5723e23b799478c.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b39acd8c5fc1c33fad988c57a8a4a02',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/4f3357f9adc7559d7d3b0401e09c1071.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '069aecd0eeec6d7793bb1271541e9332',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/9b78786236dbcb44c0b5bc2c5cf1ed10.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03fe9d8b3c6f42f21fd6e6a8bd9c5c60',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/790da02c2eef9eb4e56721651f68acbf.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f7b1217b6d10a3483daf074aba8179c',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/5228d379775bf12a9742d6d27aacf0af.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '311e600a3662ce75c7d2c7b05e42af69',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/28e9cae7518bbad2d1bc0c1d6e089982.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a2cbc45156ed338a94d55d3cfc4fc5e',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/2dc7e82a43279505cf2ca5a46e85cc40.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e06181ad15e77dedc07119af405c7e10',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/c02571cea0ef609e0336d838617c93e9.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c32cfc500f6309a6d9ad62533372740',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/195a6c4ed806e8aaaa45a5178909cc0c.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad6d7bf2433b039623f29b703df3f488',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/b5dde71f9213261e95d807916e4590bc.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4926dd4fbcc0dde0279a810964c3f5b',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/f557cee6a3e1602a7ee4035ce2e834a6.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6be32488de5e6efafa05f9d9abe479ab',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/18c8d1909ee87682e331c8e1f9f07ae7.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06a0d6a6f6441088c6c946c98d6fa60d',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/84867166b3492ea0cdaed2a9b334050f.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84f345cd167d6d5ec1079632c72bbc4b',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/683552c34765a9fdbd4d8f423c342f32.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c42d31b3ab237698c5d293f0521168b',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/12820d4852f580e12a3caae224b9efd3.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70a176bf8eb442a7f1c1f9e89c2c8530',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/9838275cfa8b1869bbf19b99764f7397.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e3d2f8420a30c8b19935b594cbbfb66',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/dc5accf422df551bfda0a280c78cb63d.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9976149d2871dcb45504fc22986fb588',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/d0ba8f39bd3d7f861db30c314edccf76.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '264d21d7db88e4c44e8dbbe4512f2469',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/b0eba30e477bdea9f8b0343490c23722.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9682e0f144b704bd350d324cfd292dd',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/e1c5ccf9beeb2e436afd099eaf8c1c23.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b4892ca493617334051c784ea714d7b',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/c502609fdcab29285c6df65750946632.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5a4a2818d0f8a1c12d45bed94a527b7',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/d5c8d5fc32ca8b8e1f0f7160653d1434.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f24cbdd531cc9d5dba81d3038e57f61',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/a129781858ee4516868a0c76b8a4bcb4.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b73c3f44489d2f59c0d7c173540e2f9',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/f068bbb10d2edd589885e9ef1ef31d66.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b6c8caef62081ce10b269eeb4e5bf3d',
      'native_key' => 'session_cookie_samesite',
      'filename' => 'modSystemSetting/18a060a5ee9ec59e5cd1890e996581be.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8a849d3557df9a1bea5f9b16db5d4b5',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/8211a0ca8cb3bbe1e752cf447dc7d601.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c475d53289d5c8babb45d4c9025e0353',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/c96717fb50e28d9556dbca1d4dd737ff.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b27a9fd370beed38009769813825b3cd',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/4f666fca6e35afca7005f03ca497d928.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ea3540fded92014efddbbe8997aa6df',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/9fe06cbb37a9865adad65bc03f1309cc.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74b5a2727196eb3aba6d81313014b648',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/6fdab6cc77d82c1956912c8ca73cec75.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '313ace903ff1905c26e5a788cc215327',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/962813ed91c01788856b7bfa498b1195.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '636574c852558438c6c5514c807abad0',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/c09f23ff7d9f152bc3d4059cfa47c897.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc4d2218612035a48dca837d86e31b48',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/b57204484ee2a5232444d5d6ae33b988.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a891e3f9e5414e8395d8a3ac0b84a61b',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/95a8c4c68601653b63760036a4b528e3.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '248b38122a4edaceef403f2d350f9b5d',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/647d0a4d8299748bae4a2a6c396b59d9.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07621710fe2153bd0507f43351dbf3ec',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/949a30abd7337e70abde8f597f499f11.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cd87f94a5d4460e5db0da129be28ecc',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/56f1e27083d224c5a217b988ca53bc54.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e51560cd61059a4a3d89ce498a711740',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'modSystemSetting/653589199437d5a3ac86cfef0fcdbb9c.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '459147612c8494b2afa5a6d61815e6fe',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'modSystemSetting/64b7b5f39491dab1f258e466a5c2afb7.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03cae4ccf7c7e49cf12b3b1c19f65f8f',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'modSystemSetting/bfb08577f23e0323ce6ff17eec8f2c4c.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7effffd348f8574e190e49255a0946e2',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'modSystemSetting/30362eb8d199cc9562567df6647a62d5.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a42576a8fa6178384028140740c0ceb',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'modSystemSetting/9648858023af98e3e86b1805e4ac5b83.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eca222321d444e8da01c119631ed1c52',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'modSystemSetting/eed8b99d621cfa196ead2c64d5aee526.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1cce52ef156051431d904ed928cdbd4',
      'native_key' => 'static_elements_default_category',
      'filename' => 'modSystemSetting/27eba26d007a4b87d05e5368e0c6297a.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '705fcc51c930acd8210d21df7095233b',
      'native_key' => 'static_elements_basepath',
      'filename' => 'modSystemSetting/1e7856d81bcaaee00f2ee04324210c1d.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cdabb591992f96e96702fd782bb86ffc',
      'native_key' => 'resource_static_allow_absolute',
      'filename' => 'modSystemSetting/32b95a648fe9d15622eed064a49eef55.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fa32f95a6246729d0951adf2a68aea5',
      'native_key' => 'resource_static_path',
      'filename' => 'modSystemSetting/b97527fed809d950ff5d4ae76f6b7487.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '600a026640569d3c9a84c52aae41efb0',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/456cf28eb0ac611c365d0a35b6e57376.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ada1807a46a27af66e6f57fac9d2ea54',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/915782df9f7e93a328024c1809b4165f.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66b4323fcfeb297be8e806e2739256dd',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/b247d9e2d90a4123a1c2b952778363c3.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eae491284e043b30283aa579b3f3df3f',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/a0be6e321eb4d9009559def86576927a.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '611959b2cc974a1f8953ceb9fd16ab40',
      'native_key' => 'topmenu_subitems_max',
      'filename' => 'modSystemSetting/94c02eaaad5ab7a01baf806a47b2c148.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09515c88eb9efaf0213ede6914b0f18e',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/190e504ce70d529a768b4ff72222388e.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '719eeea5e20b2e496f56a5d4e5024f37',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/fbb7e6748392203a2e70d3cc75c3beef.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7849f813f6688eb62d469d385fdbb8e6',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/22e8747897dc59e39eac7fef98c18886.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcd1cb2e891b98f62aec6c5ee3f943b5',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/1b4ce5592c453b5041a68bdec9e3c89d.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2801607c5510530a7aa57f01abe7fe96',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/7d2282528c90f063c9886ded8c031846.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e48a37d19f81a58fa15e8c2a942de315',
      'native_key' => 'upload_check_exists',
      'filename' => 'modSystemSetting/3acb10af81ac5569d7931a5309888645.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48a485590ef04e20b48aa466458afb5b',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/fd53e0bfc6c5f261ff28b8f70bbf752c.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8db8245b157bc0bfa33c698bc06de5b3',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/226542cd4e2569a091c1d68b23ff7469.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b598d5679eec6299f797161c9273635d',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/7543f1c74945f47b731da6c3ada3a68e.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0a3a32efece2045a1b022806db9f79a',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/6e8ade18905c2f0e81cffeb3ba42cfd3.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b19b3e9dc8664367386ae2e028592300',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/2497eacbe8f3657927a061b8baad0cd1.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd93f2cd98b35d62d17e52b9b515e2759',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/ddba44fcefaa6826284f6a7cb85e789f.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93a1d40c1ab17c3e87874974b62b3a06',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/4a3bd30b35830aea3242dd1f50024c53.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f52d2c1b8d1ed0dfcd9eb4a961a520b8',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/fcfb6a6b4839641d890f2a63b2a5c649.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb6cdb25268a89ea676f93ed1a7580a7',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/5d0015598e65309b332c65297935c884.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87cbf2f858c0a2745044cd6bba909262',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/767373e865ec67a7293c5ed563e097b8.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6178ba90387660e3dff8d62eb7d4b380',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/df5389107557691285a92bca69518610.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5755faa87c3605e398c66c0d653c63e',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/03c3118d801290774150974d52fe4395.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2cf62627a8c8405c27a8841f0f89d52',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/8c4aeb490b3c1a99760d61753618f68d.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9b579d8f1c823607321c90fd993671a',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/42f0cd4c0f977652868042810551cda9.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6a2f8f8701db851f1cf658193fb2c87',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/fb8a88b8ad8fb83ebf1fe36c2e1408bb.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '041c5971cbd93980d5c99e299ad2930d',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/1fb66946b9b4d132fda3da8f303cc968.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e4b37974976fd44743883b260bca081',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/dfcabf124d2c2c4182f47bdd997f60bc.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57db3a9018f652ea1b15a5e6cd641010',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/a551adb5433888a08fcd8a030bb9efa3.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '093eec7a0ed3c02cf46a0ab5adc834ca',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/3181b1a9d13357d3fdb8cc85ecb69f53.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad86ab9f8cb9793346e561dd80f8ba6f',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/ffb2eb29ec8d4d5347a6a87d4b23d2f0.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2515808c82279bb93b0b048bfe80cfe0',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/d791115697b71dd532f1b9e20d72db51.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f35832a754bfe914e0bbb1b787d9621b',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/d07943843ad872efe7d27a2cb207bc6e.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd29451eb2bc22592f1dcf10f6aeb7956',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/44850bbae0cc72c76bb6298276c32114.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c211eda3492d0469a938892708a5a52a',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/7c8d23d597db6d5bb2b0d3bc4a5e3433.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10057bfad3f70418123f42f444199449',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/f53721de8325957025537156b523e38c.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f196f7ca6aaa01e7479d8b70c6bbb6ec',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/93f4dc4adb539e7924dd14bdf70fc778.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f112eb69100ecf3072d2f647087e0fb4',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/02563bb48e4fd8b143afb8740b9bcc7e.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '132055abc2ecb656aedc5d160c1f5588',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/fbc69e68566988f5021b55e935c6e566.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf65eda74456a07ab7d602ab8985e27d',
      'native_key' => 'allow_tv_eval',
      'filename' => 'modSystemSetting/1f3f3775bfc2e2905c12db34fd5ea7f7.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54ae65b35dfc49d189faaecb33f001b8',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/916cae9793307616fbdb3fb96c27be0b.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf029332430e1d72903e5fb9bdff6634',
      'native_key' => 'error_log_filename',
      'filename' => 'modSystemSetting/340a3c793fe019a79f76bf13b05bb0c8.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '031ef2ce63e700c8dea119268e7d231c',
      'native_key' => 'error_log_filepath',
      'filename' => 'modSystemSetting/44392b6aa4c87ce40f71b5b370068a5c.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8fa60352bca554f816b02454773ad62',
      'native_key' => 'static_elements_html_extension',
      'filename' => 'modSystemSetting/10df26ca7d00979e9a36efb56134a23e.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '55d1a91ef133ea5dc501e2a5c4bfe54d',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/6c50f85f271f1e8d2ec49a91b4b6cbf2.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'ac30a3496c8165b291b5b47b00a44af6',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/8bee4379eceb1702689753dc7f673b45.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '850affcfdd46efca9bdc64c833c5f008',
      'native_key' => 1,
      'filename' => 'modUserGroup/4986caa2f87af1e5d0a0ea987fdea81f.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'd0827a51ad9a15aad8afd050ad7e1f69',
      'native_key' => 1,
      'filename' => 'modDashboard/ad2ee2c189fe58f5a015adb6d99692d7.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => 'f1a63c84f48dcece92328e9a9bc17c71',
      'native_key' => 1,
      'filename' => 'modMediaSource/f40df97aea0a76192992ecbfbbd32dca.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '128261b618b0f2b0f571401f6b675962',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/a6300718410af59b0826221893d9503d.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '142be7f109be7b25656bef9f60c1ab64',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/2d7c631fc3338606212b2549165a0cf9.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '9fcb53655592a174b19d7688982c39de',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/02f46b5e20865229ff3e718a16c8f21b.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'aedcd3b2b1471defa90b6e8f0b070871',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/2a4ab68cdbaa4697f9aefa5f002a30b9.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '622734c62f2390bbc99fb03af8b35cc6',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/b571d066929311eb19e673823665a96e.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'ae5f258bf27ce550a19c69d4282080b8',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/03110acf2ff3f500aae8d4f2cc05cf3d.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '85374ae92e4a33417ce126c23fcccfcf',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/a55cfe864380dba02c97ba8831e0e4d9.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'd1ad58ec67746ade03d7fd8159f07f3e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/6fdfaaa4d9c2f158afac50f727ef8b47.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '41c69251e9688edc040faf0910058b93',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/33725008f0940381e7b84e945a56375e.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '783ec46e5c4ee3b8c129024da1d9864c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/e30a0f0effc337178fe77f47cbe20ab9.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '7e68c507a6460dc38683eef6a8c6a3ad',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/c167232b226f4c2f75e4998afe6cfad0.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'f7849cda2fc7d38dd41f7d08add51d5b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/3542c4607354e02f0ec518e36a6e3aca.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '0549097a061887f83f6302b0aaaed457',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/8d9414c65b2c72ee871c1b50df8ad1f9.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'f7a86164497e3a1d9fcb0d388bc5dd7d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/175405d24640fe5abf5475533c01a0b7.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '35557fb2f41fa79e7047fe6962b51e6f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/2ae8d4043b5b208cc6d49b3b47d7d78b.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '7ee3407deeee47b5ea63a7bf41ad96f2',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/5574374ee684bde01a863ca61a270845.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'bb5ac12da2a01ee9efa47953e824fe19',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/80f37c6a1e9277e0757aae161da75cf1.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '7d59e365314d5761027aebcc5f036d99',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/bf4b165b0e26aa1e285e0c75f49edb41.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '8b1808fc1826a35d0914004b181b088b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/e8f7f5c4f1c32ee12cf4491036ddcc5f.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '5d552a19db50884ba81fd54341e370b1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/1788229d5916ffc225654c077ab5ce01.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'cbb224020a56b95af9f6d64329eb014a',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/a155631ddcaaa3daa8fa2b8a61b9d0eb.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6ae01423c23729b7dd687d25041bded7',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/6f774004e1640352a37f53dcde01c75f.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '5658a4c4bab5d53154001f7a549ddc28',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/6a9d105b30ae8b68c0ceb669b278a1dd.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8bbd024f91774bba00f6de62ae4feb14',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/7ae5e9f7515d2bbcf24def989d845ac9.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ff71d06c9173cee3d817109270bd54bf',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/5f31e343af50503b2e66a5f155db2709.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e1f659dc185bcbd203db77072234dd1f',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/e91c3622534779aa5347ef866579f063.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ce15a53d7d96010940ae898fdd67ca7b',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/5ac7f905702764330006aa11c894d249.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9a7a218fba190ad69b8a9f2ecd337da3',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/988805241c90dc749209fd417e44e3b0.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2eba7b723cc26cfeea44c90fb12617d6',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/c2eb8f414402254e373042af5feea602.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3ea553728c73a3201e03f259f70583c0',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/e8927161bb3efa5010af3e54dbd6327f.vehicle',
    ),
    494 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd27c312cb2c3b1f64d3b41fddeb83538',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/d683eb368bb566aae85ec8e603bdbc80.vehicle',
    ),
    495 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '714ff3dc8418d103948d5ae980fb9691',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/cd3c5f9da9512d6c6961113fab8ba653.vehicle',
    ),
    496 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'a3bc9c6a20cf151d5505adce3322de75',
      'native_key' => 'web',
      'filename' => 'modContext/2d5ae8355f1448ecda311dbf712097bd.vehicle',
    ),
    497 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'cb449aa209b2e674f6564b189b9b6880',
      'native_key' => 'mgr',
      'filename' => 'modContext/3eca5e9e55b2c554001f51f01d563134.vehicle',
    ),
    498 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'b735821fc12013d99b2a554f3d9a6a3e',
      'native_key' => 'b735821fc12013d99b2a554f3d9a6a3e',
      'filename' => 'xPDOFileVehicle/18caccf4974fefd03446df2285c89d22.vehicle',
    ),
    499 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '70bafa0b774e973cb768e546ed925ded',
      'native_key' => '70bafa0b774e973cb768e546ed925ded',
      'filename' => 'xPDOFileVehicle/5d069a0367d31f9b61ce75bccbc3e16f.vehicle',
    ),
    500 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '809efb599f6dc4cefd91877fa8c20d5a',
      'native_key' => '809efb599f6dc4cefd91877fa8c20d5a',
      'filename' => 'xPDOFileVehicle/df5655ba000e430b07875cab2b42847e.vehicle',
    ),
    501 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '394580e2584923819fd0f2f49df47e4a',
      'native_key' => '394580e2584923819fd0f2f49df47e4a',
      'filename' => 'xPDOFileVehicle/fd9016766f8870376520b122b0e7a034.vehicle',
    ),
  ),
);